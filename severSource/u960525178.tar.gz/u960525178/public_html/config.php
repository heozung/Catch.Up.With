<?php
error_reporting(0);
$db_host = "localhost"; // Giữ mặc định là localhost
$db_name    = 'u960525178_abc';// Can thay doi
$db_username    = 'u960525178_xyz'; //Can thay doi
$db_password    =  'khanhvip';//Can thay doi
mysql_connect($db_host, $db_username, $db_password) or die("Không thể kết nối database");
mysql_select_db($db_name) or die("Không thể chọn database");
?>